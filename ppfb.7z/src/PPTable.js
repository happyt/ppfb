import React, { Component } from 'react';

export default class PPTable extends Component {

    constructor(props) {
        super(props);
        
        const startNo = this.props.group * 10;
        const grp = ["A", "B", "C", "D", "E", "F", "G", "H"].splice(this.props.group,1);
        this.state = {grp: grp, start: startNo, matches: this.props.db.matches.Matches.slice(startNo, startNo+10)};
    }
    render() {
        const listItems = this.state.matches.map((mm,index) => (
            <tr><td key={index}>{mm.PlayerA}</td><td>{mm.PlayerB}</td><td>{mm.AddText}</td></tr>
        ));

        return (
            <div>
                <table>
                <tr><td>GROUP {this.state.grp}</td><td></td><td>scores</td></tr>
                 {listItems}
                 </table>
            </div>
        );
    }
}