import React, { Component } from 'react';
import logo from './logo.svg';
import PPTable from './PPTable.js';
import './App.css';
import './PPTable.css';

export default class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h2>World Championship Ping Pong</h2>
        </div>
        <PPTable group="0" db={this.props}/>
        <PPTable group="1" db={this.props}/>
        
                <p>{JSON.stringify(this.props.matches.Matches[0])}</p>
      </div>
    );
  }
}
